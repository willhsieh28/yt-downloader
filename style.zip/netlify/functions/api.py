import json
import logging
import yt_dlp

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    # Only allow POST requests (or GET with query params if you prefer)
    if event['httpMethod'] != 'POST':
        return {
            'statusCode': 405,
            'body': json.dumps({'error': 'Method Not Allowed'})
        }

    try:
        body = json.loads(event['body'])
        url = body.get('url')
        
        if not url:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'URL is required'})
            }

        ydl_opts = {
            'format': 'best[ext=mp4]/best',  # Try to find a single file with audio+video
            'quiet': True,
            'no_warnings': True,
            'noplaylist': True,
            # We don't download, we just want the info
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Extract relevant info
            video_url = info.get('url')
            title = info.get('title')
            thumbnail = info.get('thumbnail')
            duration = info.get('duration_string')
            uploader = info.get('uploader')
            
            # Check if we got a direct URL
            if not video_url:
                 return {
                    'statusCode': 500,
                    'body': json.dumps({'error': 'Could not resolve video URL'})
                }

            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                     'Access-Control-Allow-Origin': '*' # Ideally restrict this in production
                },
                'body': json.dumps({
                    'title': title,
                    'url': video_url,
                    'thumbnail': thumbnail,
                    'duration': duration,
                    'uploader': uploader
                })
            }

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
